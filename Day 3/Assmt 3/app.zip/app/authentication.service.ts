import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Buyer } from './model/buyer';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  token: string = "";
  userID: string = "";
  status: string = "";
  userType: string ="";
  firstName: string = "";
  authenticationApiUrl = "http://localhost:8083/authentication-service/smart-shop/authentication";
  buyer!: Buyer;
  constructor(private httpClient: HttpClient) { }

  getBuyer() {
    return this.buyer;
  }

  authenticate(userID: string, password: string): Observable<any> {
    let credentials = btoa(userID + ':' + password);
    let headers = new HttpHeaders();
    headers = headers.set('Authorization', 'Basic ' + credentials);
    return this.httpClient.get(this.authenticationApiUrl, { headers });
  }

  getToken(){
    return this.token;
  }

  setToken(token: string){
    this.token = token;
  }

  getUserID(){
    return this.userID;
  }

  setUserID(userID: string){
    this.userID = userID;
  }

  getStatus(){
    return this.status;
  }

  setStatus(status: string){
    this.status = status;
  }

  getUserType(){
    return this.userType;
  }

  setUserType(userType: string){
    this.userType = userType;
  }

  getFirstName(){
    return this.firstName;
  }

  setFirstName(firstName: string){
    this.firstName = firstName;
  }

  userLoggedOut() {
    this.userType = "";
    this.status = "";
  }
}