import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { AuthenticationService } from './authentication.service';
import { Cart } from './model/cart';
import { Product } from './model/product';
import { PurchaseHistory } from './model/purchase-history';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  productObs!: Observable<Product[]>;

  productList!: Product[];
  cartList: Cart[] = [];
  purchaseList: PurchaseHistory[] = [];

  constructor(private httpClient: HttpClient, private authenticationService: AuthenticationService) { }

  getProduct(code: any) {
    let token = 'Bearer ' + this.authenticationService.getToken();
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': token
      })
    }
    return this.httpClient.get("http://localhost:8083/product-service/smart-shop/products/" + code, httpOptions);
  }

  deleteProduct(code: any) {
    let token = 'Bearer ' + this.authenticationService.getToken();
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': token
      })
    }
    return this.httpClient.delete("http://localhost:8083/product-service/smart-shop/products/" + code, httpOptions);
  }

  getAllProducts() {
    // let token = 'Bearer ' + this.authenticationService.getToken();
    // const httpOptions = {
    //   headers: new HttpHeaders({
    //     'Content-Type': 'application/json',
    //     'Authorization': token
    //   })
    // };
    // return this.httpClient.get<any>("http://localhost:8083/product-service/smart-shop/products", httpOptions);

    this.productList = this.getProductsHardCoded();

    let obs = new Observable((observer) => {
      observer.next(this.productList);
    })
    return obs;
  }

  getCartList() {
    // let token = 'Bearer ' + this.authenticationService.getToken();
    // const httpOptions = {
    //   headers: new HttpHeaders({
    //     'Content-Type': 'application/json',
    //     'Authorization': token
    //   })
    // };
    // return this.httpClient.get<any>("http://localhost:8083/product-service/smart-shop/products", httpOptions);



    let obs = new Observable((observer) => {
      observer.next(this.cartList);
    })
    return obs;
  }

  addToCart(cart: Cart) {
    // post call

    this.cartList.push(cart);
  }

  removeFromCart(cart: Cart) {
    this.cartList.forEach(cartItem => {
      if (cartItem.product.id === cart.product.id) {
        cartItem.purchaseStatus = true;
      }
    });
  }

  checkout(cart: Cart) {
    let purchaseHistory: PurchaseHistory = {
      id: 0,
      cart: cart,
      purchaseQuantity: cart.purchaseQuantity,
      buyer: this.authenticationService.getBuyer(),
      purchaseDate: new Date()
    }

    this.purchaseList.push(purchaseHistory);

    this.cartList.forEach(cartItem=>{
      if(cartItem.product.id === cart.product.id){cartItem.purchaseStatus = true;}
    });
  }

  getPurchaseList() {
    // let token = 'Bearer ' + this.authenticationService.getToken();
    // const httpOptions = {
    //   headers: new HttpHeaders({
    //     'Content-Type': 'application/json',
    //     'Authorization': token
    //   })
    // };
    // return this.httpClient.get<any>("http://localhost:8083/product-service/smart-shop/products", httpOptions);



    let obs = new Observable((observer) => {
      observer.next(this.purchaseList);
    })
    return obs;
  }


  getAllProductsByName() {
    let token = 'Bearer ' + this.authenticationService.getToken();
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': token
      })
    };
    return this.httpClient.get<any>("http://localhost:8083/product-service/smart-shop/products/sort-by-name", httpOptions);
  }

  getAllProductsByAvailability() {
    let token = 'Bearer ' + this.authenticationService.getToken();
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': token
      })
    };
    return this.httpClient.get<any>("http://localhost:8083/product-service/smart-shop/products/sort-by-availability", httpOptions);
  }

  getAllProductsByPrice() {
    let token = 'Bearer ' + this.authenticationService.getToken();
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': token
      })
    };
    return this.httpClient.get<any>("http://localhost:8083/product-service/smart-shop/products/sort-by-price", httpOptions);
  }

  getAllProductsByPopularity() {
    let token = 'Bearer ' + this.authenticationService.getToken();
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': token
      })
    };
    return this.httpClient.get<any>("http://localhost:8083/product-service/smart-shop/products/sort-by-popularity", httpOptions);
  }







  getProductsHardCoded() {
    let productList: Product[] = [
      {
        id: 1,
        productName: "One Plus",
        productModel: "string",
        brandName: "string",
        category: "Electronics",
        subCategory: "Mobile",
        productPrice: 200,
        quantity: 1000,
        image: "https://i.pcmag.com/imagery/reviews/01pr6hmgqz7A5wX5hSQWqRs-1.fit_lim.size_625x365.v1632764534.jpg",
        productSpecs: "string",
        sellerId: 2,
        status: "active"
      },
      {
        id: 2,
        productName: "Travel Bag",
        productModel: "abcd",
        brandName: "abcd",
        category: "Electronics",
        subCategory: "Mobile",
        productPrice: 200,
        quantity: 1000,
        image: "https://5.imimg.com/data5/TL/KN/MY-33478789/trolley-travel-bag-500x500.jpg",
        productSpecs: "abcd",
        sellerId: 2,
        status: "abcd"
      },
      {
        id: 3,
        productName: "Shirt",
        productModel: "abcd",
        brandName: "abcd",
        category: "Fashion",
        subCategory: "Clothing",
        productPrice: 200,
        quantity: 1000,
        image: "https://5.imimg.com/data5/TL/KN/MY-33478789/trolley-travel-bag-500x500.jpg",
        productSpecs: "abcd",
        sellerId: 2,
        status: "abcd"
      },
      {
        id: 4,
        productName: "Jeans",
        productModel: "abcd",
        brandName: "abcd",
        category: "Fashion",
        subCategory: "Clothing",
        productPrice: 200,
        quantity: 1000,
        image: "https://5.imimg.com/data5/TL/KN/MY-33478789/trolley-travel-bag-500x500.jpg",
        productSpecs: "abcd",
        sellerId: 2,
        status: "abcd"
      },
      {
        id: 5,
        productName: "Shoe",
        productModel: "abcd",
        brandName: "abcd",
        category: "Fashion",
        subCategory: "Footwear",
        productPrice: 200,
        quantity: 1000,
        image: "https://5.imimg.com/data5/TL/KN/MY-33478789/trolley-travel-bag-500x500.jpg",
        productSpecs: "abcd",
        sellerId: 2,
        status: "abcd"
      }

    ];
    return productList;
  }

}