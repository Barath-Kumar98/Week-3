import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CartComponent } from './cart/cart.component';
import { GetProductsComponent } from './get-products/get-products.component';
import { PurchaseHistoryComponent } from './purchase-history/purchase-history.component';


const routes: Routes = [
  { path: '', component: GetProductsComponent },
  { path: 'products', component: GetProductsComponent },
  { path: 'cart', component: CartComponent },
  { path: 'purchase-history', component: PurchaseHistoryComponent }
  // { path: 'product-list', component: ProductListComponent, canActivate: [AuthGuard]},
  // { path: 'add-product', component: AddProductComponent, canActivate: [AuthGuard]},
  // { path: 'edit-product/:code', component: EditProductComponent, canActivate: [AuthGuard]},
  // { path: 'edit-product', component: EditProductComponent, canActivate: [AuthGuard]},
  // { path: 'registration-request', component: RegistrationRequestComponent, canActivate: [AuthGuard] },
  // { path: 'bill', component: BillComponent, canActivate: [AuthGuard] },
  // { path: 'drop-bill', component: BillComponent, canActivate: [AuthGuard] },
  // { path: 'purchase-history', component: PurchaseHistoryComponent, canActivate: [AuthGuard] },
  // { path: 'forgot-password/:forgot', component: ForgotPasswordComponent },
  // { path: 'forgot-password', component: ForgotPasswordComponent },
  // { path: 'add-offer', component: AddOfferComponent, canActivate: [AuthGuard] },
  // { path: 'update-offer/:id', component: UpdateOfferComponent, canActivate: [AuthGuard] },
  // { path: 'update-offer', component: UpdateOfferComponent, canActivate: [AuthGuard] },
];



@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
