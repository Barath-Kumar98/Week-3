package com.eg.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.AuthenticationException;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.eg.config.JwtTokenUtil;
import com.eg.model.ApiResponse;
import com.eg.model.AuthToken;
import com.eg.model.LoginUser;
import com.eg.model.User;
import com.eg.model.UserDto;
import com.eg.service.UserService;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/token")
public class AuthenticationController {

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private JwtTokenUtil jwtTokenUtil;

    @Autowired
    private UserService userService;

    @RequestMapping(value = "/generate-token/{time}", method = RequestMethod.POST)
    public ApiResponse<AuthToken> register(@RequestBody LoginUser loginUser, @PathVariable("time") long time) throws AuthenticationException {

        authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(loginUser.getUsername(), loginUser.getPassword()));
        final User user = userService.findOne(loginUser.getUsername());
        final String token = jwtTokenUtil.generateToken(user, time);
        System.out.println("Role is:"+user.getRole());
        return new ApiResponse<>(200, "success",new AuthToken(token, user.getUsername(), user.getRole()));
    }
    
    @RequestMapping(value = "/signup", method = RequestMethod.POST)
    public String signup(@RequestBody LoginUser loginUser, HttpServletRequest hsr) throws AuthenticationException {
    	System.out.println("Remote addr:"+hsr.getRemoteAddr()+":::"+hsr.getRemoteHost());
    	UserDto udto = new UserDto();
    	udto.setUsername(loginUser.getUsername());
    	udto.setPassword(loginUser.getPassword());
    	udto.setAge(23);
    	udto.setFirstName("firstName");
    	udto.setLastName("lastName");
        final User user = userService.save(udto);
        return "Done";
    }
    

}
