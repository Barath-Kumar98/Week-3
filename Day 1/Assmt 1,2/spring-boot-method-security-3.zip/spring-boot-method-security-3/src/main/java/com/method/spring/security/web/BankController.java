package com.method.spring.security.web;

import javax.annotation.security.PermitAll;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.method.spring.security.service.LoanService;

@RestController
@RequestMapping("bank")
public class BankController {
	@Autowired
	LoanService loanService;
	
	@GetMapping("approveloan")
    @PermitAll
    public String approveloan() {
        return loanService.approveLoan();
    }
}
