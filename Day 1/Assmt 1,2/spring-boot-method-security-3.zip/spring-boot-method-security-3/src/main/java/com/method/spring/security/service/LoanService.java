package com.method.spring.security.service;

import javax.annotation.security.RolesAllowed;

import org.springframework.stereotype.Service;

@Service
public class LoanService {
	
	
	//week 3 Day 1 Assignment 2
	@RolesAllowed({"ROLE_MANAGER"})
    public String approveLoan() {
        return "Loan Approved by Manager";
    }
}
